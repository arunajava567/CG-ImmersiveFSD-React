package com.cg;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Hospital")
public class Bed implements Serializable {
	@Id
	private int bedId;
	private String bedType;
	private int totalNumberOfBeds;
	
	
	
	public Bed() 
	{
		super();
	}

	public Bed(int bedId, String bedType, int totalNumberOfBeds) {
		super();
		this.bedId = bedId;
		this.bedType = bedType;
		this.totalNumberOfBeds = totalNumberOfBeds;
	}

	public int getBedId() {
		return bedId;
	}

	public void setBedId(int bedId) {
		this.bedId = bedId;
	}

	public String getBedType() {
		return bedType;
	}

	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public int getTotalNumberOfBeds() {
		return totalNumberOfBeds;
	}

	public void setTotalNumberOfBeds(int totalNumberOfBeds) {
		this.totalNumberOfBeds = totalNumberOfBeds;
	}
	
	

}
