package com.cg;

public interface BedDao {
	
	public void addBedById(Bed bedId);
	public void updateBedById(int bedId);
	public void deleteBedById(int bedId);

}
