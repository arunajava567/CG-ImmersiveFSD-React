package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class BedDaoImpl implements BedDao {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("examplePU");
    EntityManager entityManager=emf.createEntityManager();
	public void addBedById(Bed bedId)
	{
		entityManager.getTransaction().begin();
		entityManager.persist(bedId);
		System.out.println("added");
		entityManager.getTransaction().commit();
	}
	
	public void updateBedById(int bedId)
	{
		entityManager.merge(bedId);
	}
	
	public void deleteBedById(int bedId)
	{
		entityManager.remove(bedId);
	}

}
