package com.cg;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Client;

public class DisplayAllClients {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
		EntityManager em = emf.createEntityManager();
		                              //select * from , from HQL "from Client c"     JPQL" select c from client c"
		List<Client> clientes = em.createQuery("from Client c", Client.class).getResultList();
		for(Client client : clientes){
			System.out.println("Id: " + client.getId());
			System.out.println("NAme: " + client.getName());
			System.out.println("Profession: " + client.getProfession());
			System.out.println("Gender: " + client.getGender());
			System.out.println("---------------------------");
		}

	}

}
