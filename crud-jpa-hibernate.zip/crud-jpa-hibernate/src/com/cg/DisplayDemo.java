package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Client;

public class DisplayDemo {
	
	public Client getClient() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
		EntityManager em = emf.createEntityManager();
		
		
			
			Client client = em.find(Client.class, 2L); //select load a record  for the given primary key 
	  return client;
	}

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
		EntityManager em = emf.createEntityManager();
		
		try {
			
			Client client = em.find(Client.class, 2L); //select load a record  for the given primary key 
			
			if(client != null){
				System.out.println("Id: " + client.getId());
				System.out.println("NAme: " + client.getName());
				System.out.println("Profession: " + client.getProfession());
				System.out.println("Gender: " + client.getGender());
			}else{
				System.out.println("display success!");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

}
