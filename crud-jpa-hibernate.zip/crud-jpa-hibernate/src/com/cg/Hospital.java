package com.cg;

public class Hospital {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BedDao bd = new BedDaoImpl();
		Bed b = new Bed();
		b.setBedId(1);
		b.setBedType("single");
		b.setTotalNumberOfBeds(100);
		bd.addBedById(b);

	}

}
