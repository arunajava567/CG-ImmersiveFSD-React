package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Client;

public class RemoveDemo {
	
	public static void main(String args[]){
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
		EntityManager em = emf.createEntityManager();
		
		Client client = em.find(Client.class, 2L);
		
		try {
			em.getTransaction().begin();
			em.remove(client);   //delete 
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			e.getMessage();
		}
		
		em.close();
		
		System.out.println("Remove success!");
		
	}
}
