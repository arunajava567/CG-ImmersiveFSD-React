package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Client;
import com.cg.util.JPaUtil;

public class SaveDemo {
// add,  update, delete, list
	public static void main(String[] args) {
		
		EntityManager em = JPaUtil.getEntityManager();  
		
		Client client= new Client(); //entity is create d--new 
		client.setName("AravReddy");
		client.setProfession("FSEngineer");
		client.setGender("Male");
		try {
			em.getTransaction().begin();  //begin 
			em.persist(client);      //managed stated  ... pushed database ,insert 
			em.getTransaction().commit(); //end
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			e.getMessage();
		}
		em.close();  //manager is clsed 
		
		System.out.println("Client salved successfully!");
		
	}

}