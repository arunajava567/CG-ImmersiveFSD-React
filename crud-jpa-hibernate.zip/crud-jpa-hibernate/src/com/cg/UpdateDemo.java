package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Client;

public class UpdateDemo {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
		EntityManager em = emf.createEntityManager();
		
		Client client = em.find(Client.class, 1L);
		
		try {
			em.getTransaction().begin();
			client.setName("XXXX");  //update 
			client.setProfession("FSE");
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			e.getMessage();
		}
		System.out.println("Update Client!");

		em.close();
		
	}

}
