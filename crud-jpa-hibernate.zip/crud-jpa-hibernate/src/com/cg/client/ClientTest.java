package com.cg.client;

import java.io.IOException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.model.Client;
import com.cg.service.ClientService;
import com.cg.service.ClientServiceImpl;
public class ClientTest {

	public static void main(String[] args) throws IOException{
		ClientService clientServie=new ClientServiceImpl();
		
		//step1  cretaing logger
		 Logger logger = Logger.getLogger("ClientTest.class");
			
		System.out.println("Client Menu");
		System.out.println("1. Save client");
		System.out.println("2. Remove client");
		System.out.println("3. Update client");
		System.out.println("4. Display client");
		System.out.println("5. Display All clients");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter you choice");
		int ch=sc.nextInt();
		switch(ch) {
		case 1:		{        Client client= new Client(); //entity is create d--new 
							 System.out.println("enter name,profession,gender");
							 client.setName(sc.next());
		                     client.setProfession(sc.next());
		                     client.setGender(sc.next()); 
		                     // logger.info -- file e:\\output.txt
		                     logger.info(client.toString());
		                   // info, error, trace, fatal,warn,debug 
			         clientServie.saveClient(client);
			         logger.info("save is success");
			         break;}
	
		case 2: { System.out.println("enter client id to be removed ");
					Long id=sc.nextLong();
					clientServie.removeClient(id);
					break;}
		default : System.out.println("Wrong Choice");

	}
	}
}
