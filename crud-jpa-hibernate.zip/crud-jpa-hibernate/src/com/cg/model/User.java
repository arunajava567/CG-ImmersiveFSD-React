package com.cg.model;
/*
@Entity
@Table(name="User")
public class User {
	@Id
	Integer id;
	@Column
	String name;
	

}
*/