package com.cg.repository;

import java.io.IOException;

import com.cg.model.Client;

public interface ClientRepository {
	public void saveClient(Client client) ;
	public void removeClient(Long id);
	public void displayAllClients();
	public void displayClient();
	public void updateClient();
}
