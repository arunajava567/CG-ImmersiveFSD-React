package com.cg.repository;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;

import com.cg.model.Client;
import com.cg.util.JPaUtil;

public class ClientRepositoryImpl {
	public void saveClient(Client client)  { 
		 Logger logger = Logger.getLogger("ClientRepositoryImpl.class");
			
		EntityManager em = JPaUtil.getEntityManager();  
		logger.info(" starting dao");
	try {
		em.getTransaction().begin();  //begin 
		em.persist(client);      //managed stated  ... pushed database ,insert 
		em.getTransaction().commit(); //end
	} catch (Exception e) {
		em.getTransaction().rollback();
		e.printStackTrace();
		e.getMessage();
	}
	em.close();  //manager is clsed 
	System.out.println("Client salved successfully!");
	logger.info(" end of DAO !");
	}
	public void removeClient(Long id) {
		EntityManager em = JPaUtil.getEntityManager();  
		Client client = em.find(Client.class, id);
	try {
			em.getTransaction().begin();
			em.remove(client);   //delete 
			em.getTransaction().commit();
		} 
		catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			e.getMessage();
		}
		
		em.close();
		
		System.out.println("Remove success!");
	
	}
	
	public void displayClient() {
	try {
		EntityManager em = JPaUtil.getEntityManager();  

			Client client = em.find(Client.class, 2L); //select load a record  for the given primary key 
			
			if(client != null){
				System.out.println("Id: " + client.getId());
				System.out.println("NAme: " + client.getName());
				System.out.println("Profession: " + client.getProfession());
				System.out.println("Gender: " + client.getGender());
			}else{
				System.out.println("display success!");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}
	public void displayAllClients() {
		EntityManager em = JPaUtil.getEntityManager();  
		                              //select * from , from HQL "from Client c"     JPQL" select c from client c"
		List<Client> clientes = em.createQuery("from Client c", Client.class).getResultList();
		for(Client client : clientes){
			System.out.println("Id: " + client.getId());
			System.out.println("NAme: " + client.getName());
			System.out.println("Profession: " + client.getProfession());
			System.out.println("Gender: " + client.getGender());
			System.out.println("---------------------------");
		}
	}
	
	public void updateClient() {
		EntityManager em = JPaUtil.getEntityManager();  

		Client client = em.find(Client.class, 1L);
		
		try {
			em.getTransaction().begin();
			client.setName("XXXX");  //update 
			client.setProfession("FSE");
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
			e.getMessage();
		}
		System.out.println("Update Client!");

		em.close();
		
	}
}
