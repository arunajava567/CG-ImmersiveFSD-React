package com.cg.service;

import java.io.IOException;

import com.cg.model.Client;

public interface ClientService {
	public void saveClient(Client client) ;
	public void removeClient(Long id);
	public void displayAllClients();
	public void displayClient();
	public void updateClient();
}
