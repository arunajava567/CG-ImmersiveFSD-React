package com.cg.service;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.cg.model.Client;
import com.cg.repository.ClientRepositoryImpl;


public class ClientServiceImpl implements ClientService{
	ClientRepositoryImpl clientRepository=new ClientRepositoryImpl();
	public void saveClient(Client client)  {
		 Logger logger = Logger.getLogger("ClientServiceImpl.class");
			
		logger.info("entering service");
		clientRepository.saveClient(client);
		logger.info("end of service");
		
	}
	public void removeClient(Long id) {
		clientRepository.removeClient(id);
	}
	public void displayAllClients() {
		clientRepository.displayAllClients();
	}
	public void displayClient() {
		clientRepository.displayClient();
	}
	public void updateClient() {
		clientRepository.updateClient();
	}
}
