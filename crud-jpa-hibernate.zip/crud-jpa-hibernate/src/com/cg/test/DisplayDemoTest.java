package com.cg.test;

import com.cg.DisplayDemo;
import com.cg.model.Client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DisplayDemoTest {
	DisplayDemo dd;
	@BeforeEach
	void setUp() throws Exception {
		
		dd=new DisplayDemo();
	}

	@AfterEach
	void tearDown() throws Exception {
		dd=null;
	}

	@Test
	void testGetClient() {
		Client c= dd.getClient();
		assertSame(2L,c.getId());  //DAO testing...
		
		//fail("Not yet implemented");
	}

}
