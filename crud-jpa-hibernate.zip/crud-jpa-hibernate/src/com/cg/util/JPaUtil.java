package com.cg.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPaUtil {

	public static EntityManager getEntityManager() {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
	EntityManager em = emf.createEntityManager();
	return em;
	}
}
