package com.cg.intro;

public interface ExchangeService {

	public double getExchangeRate();
}
