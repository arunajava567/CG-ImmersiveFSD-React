package com.cg.controller;

public class ProductNotFoundException  extends Exception{
	public ProductNotFoundException(String msg){
		super(msg);
	}

}
