INSERT INTO product(product_id,product_name,quantity,price) 
VALUES(1001,'mobile',3,7000.0);