INSERT INTO product(product_id,product_name,quantity,price) 
VALUES(1001,'mobile',3,7000.0);
INSERT INTO product(product_id,product_name,quantity,price) 
VALUES(1002,'bag',5,78000.0);
INSERT INTO product(product_id,product_name,quantity,price) 
VALUES(1003,'pen',4,37000.0);